package dev.smoothzoomplus;

public final class ZoomController {
    private static double current = 1.0, target = 1.0;
    private ZoomController() {}
    public static void setTarget(double value) { target = Math.max(1.0, Math.min(20.0, value)); }
    public static void tick(double speed) {
        double amount = Math.max(0.01, Math.min(1.0, speed));
        current += (target - current) * amount;
        if (Math.abs(target - current) < 0.001) current = target;
    }
    public static double getCurrent() { return current; }
}
