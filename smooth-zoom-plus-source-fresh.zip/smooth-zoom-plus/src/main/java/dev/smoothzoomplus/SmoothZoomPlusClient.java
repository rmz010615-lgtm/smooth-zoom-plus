package dev.smoothzoomplus;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public final class SmoothZoomPlusClient implements ClientModInitializer {
    public static KeyBinding ZOOM_KEY;
    public static final ZoomConfig CONFIG = ZoomConfig.load();
    private static boolean wasPressed = false;

    @Override public void onInitializeClient() {
        ZOOM_KEY = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.smooth_zoom_plus.zoom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C,
            KeyBinding.Category.MISC
        ));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            boolean pressed = ZOOM_KEY.isPressed();
            if (pressed != wasPressed) ZoomController.setTarget(pressed ? CONFIG.zoomFactor : 1.0);
            wasPressed = pressed;
            ZoomController.tick(CONFIG.transitionSpeed);
        });
        // Sharing is OFF by default. The relay only receives messages after explicit opt-in
        // and the user has configured a private relay URL/token in config.
        ClientReceiveMessageEvents.CHAT.register((message, signedMessage, sender, params, receptionTimestamp) -> {
            if (CONFIG.shareChat) ChatRelay.send(sender == null ? "System" : sender.getName(),
                message.getString(), receptionTimestamp.getEpochSecond());
        });
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (CONFIG.shareChat) ChatRelay.send("Game", message.getString(), System.currentTimeMillis()/1000L);
        });
    }
}
