package dev.smoothzoomplus;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.nio.file.Files;
import java.nio.file.Path;

public final class ZoomConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    public double zoomFactor = 4.0;
    /** Interpolation fraction per tick; higher means faster transition. */
    public double transitionSpeed = 0.28;
    public boolean shareChat = false;
    public String relayUrl = "wss://your-host.example/ws/client";
    public String relayToken = "CHANGE_ME";
    private static final Path FILE = Path.of("config", "smooth-zoom-plus.json");

    public static ZoomConfig load() {
        try {
            Files.createDirectories(FILE.getParent());
            if (Files.exists(FILE)) return GSON.fromJson(Files.readString(FILE), ZoomConfig.class);
            ZoomConfig config = new ZoomConfig(); config.save(); return config;
        } catch (Exception e) { return new ZoomConfig(); }
    }
    public void save() {
        try { Files.createDirectories(FILE.getParent()); Files.writeString(FILE, GSON.toJson(this)); }
        catch (Exception e) { System.err.println("[Smooth Zoom Plus] Could not save config: " + e.getMessage()); }
    }
}
