package dev.smoothzoomplus.mixin;

import dev.smoothzoomplus.SmoothZoomPlusClient;
import dev.smoothzoomplus.ZoomController;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** Applies zoom as a camera FOV multiplier; works in first- and third-person views. */
@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    @ModifyVariable(method = "getFov", at = @At("STORE"), ordinal = 0, require = 0)
    private double smoothZoomPlus$modifyFov(double fov) {
        if (SmoothZoomPlusClient.CONFIG == null) return fov;
        return fov / ZoomController.getCurrent();
    }
}
