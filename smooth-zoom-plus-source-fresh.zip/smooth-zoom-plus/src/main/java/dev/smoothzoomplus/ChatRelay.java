package dev.smoothzoomplus;

import com.google.gson.JsonObject;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.WebSocket;
import java.time.Duration;
import java.util.concurrent.CompletionStage;

/** Best-effort outbound-only relay. No transmission occurs unless shareChat is enabled. */
public final class ChatRelay {
    private static volatile WebSocket socket;
    private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();
    private static long lastAttempt = 0;
    private ChatRelay() {}

    public static synchronized void send(String username, String message, long timestamp) {
        var cfg = SmoothZoomPlusClient.CONFIG;
        if (!cfg.shareChat || cfg.relayToken == null || cfg.relayToken.isBlank() || "CHANGE_ME".equals(cfg.relayToken)) return;
        try {
            if (socket == null && System.currentTimeMillis() - lastAttempt > 5000) {
                lastAttempt = System.currentTimeMillis();
                socket = HTTP.newWebSocketBuilder().connectTimeout(Duration.ofSeconds(5))
                    .header("Authorization", "Bearer " + cfg.relayToken)
                    .buildAsync(URI.create(cfg.relayUrl), new WebSocket.Listener() {
                        @Override public void onOpen(WebSocket ws) { WebSocket.Listener.super.onOpen(ws); }
                        @Override public CompletionStage<?> onText(WebSocket ws, CharSequence data, boolean last) { return null; }
                        @Override public void onError(WebSocket ws, Throwable error) { socket = null; }
                        @Override public CompletionStage<?> onClose(WebSocket ws, int statusCode, String reason) { socket = null; return null; }
                    }).join();
            }
            if (socket != null) {
                JsonObject json = new JsonObject();
                json.addProperty("type", "chat"); json.addProperty("username", username);
                json.addProperty("message", message); json.addProperty("timestamp", timestamp);
                socket.sendText(json.toString(), true);
            }
        } catch (Exception e) { socket = null; }
    }
}
