import 'dotenv/config';
import express from 'express';
import { WebSocketServer, WebSocket } from 'ws';
import crypto from 'node:crypto';
import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ noServer: true, maxPayload: 16 * 1024 });
const PORT = Number(process.env.PORT || 8080);
const CLIENT_TOKEN = process.env.CLIENT_TOKEN || '';
const DASHBOARD_USER = process.env.DASHBOARD_USER || '';
const DASHBOARD_PASSWORD = process.env.DASHBOARD_PASSWORD || '';
const history = [];
const MAX_HISTORY = 500;
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const safeEqual = (a, b) => {
  const aa = Buffer.from(String(a)), bb = Buffer.from(String(b));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
};
const basicAuth = (req, res, next) => {
  const header = req.headers.authorization || '';
  const [scheme, encoded] = header.split(' ');
  if (scheme !== 'Basic' || !encoded) { res.set('WWW-Authenticate', 'Basic realm="Smooth Zoom Plus"').status(401).end('Authentication required'); return; }
  let decoded = '';
  try { decoded = Buffer.from(encoded, 'base64').toString('utf8'); } catch {}
  const split = decoded.indexOf(':');
  if (split < 0 || !safeEqual(decoded.slice(0, split), DASHBOARD_USER) || !safeEqual(decoded.slice(split + 1), DASHBOARD_PASSWORD)) {
    res.set('WWW-Authenticate', 'Basic realm="Smooth Zoom Plus"').status(401).end('Invalid credentials'); return;
  }
  next();
};
if (!CLIENT_TOKEN || !DASHBOARD_USER || !DASHBOARD_PASSWORD) {
  console.error('Set CLIENT_TOKEN, DASHBOARD_USER and DASHBOARD_PASSWORD in .env before starting.');
  process.exit(1);
}
app.use('/api', basicAuth);
app.get('/api/history', (_req, res) => res.json(history));
app.get('/api/status', (_req, res) => res.json({ connected: [...wss.clients].some(c => c.role === 'dashboard' && c.readyState === WebSocket.OPEN), count: history.length }));
app.use(express.static(path.join(__dirname, 'public')));
server.on('upgrade', (req, socket, head) => {
  const url = new URL(req.url, 'http://localhost');
  const auth = req.headers.authorization || '';
  if (url.pathname !== '/ws/client' && url.pathname !== '/ws/dashboard') { socket.destroy(); return; }
  if (url.pathname === '/ws/client' && !safeEqual(auth.replace(/^Bearer\s+/i, ''), CLIENT_TOKEN)) { socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n'); socket.destroy(); return; }
  if (url.pathname === '/ws/dashboard') {
    const [scheme, encoded] = auth.split(' ');
    let decoded = ''; try { if (scheme === 'Basic') decoded = Buffer.from(encoded, 'base64').toString(); } catch {}
    const i = decoded.indexOf(':');
    if (i < 0 || !safeEqual(decoded.slice(0, i), DASHBOARD_USER) || !safeEqual(decoded.slice(i + 1), DASHBOARD_PASSWORD)) { socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n'); socket.destroy(); return; }
  }
  wss.handleUpgrade(req, socket, head, ws => { ws.role = url.pathname === '/ws/client' ? 'client' : 'dashboard'; wss.emit('connection', ws); });
});
wss.on('connection', ws => {
  if (ws.role === 'dashboard') ws.send(JSON.stringify({ type: 'history', messages: history }));
  ws.on('message', raw => {
    if (ws.role !== 'client') return;
    try {
      const data = JSON.parse(raw.toString());
      if (data.type !== 'chat' || typeof data.username !== 'string' || typeof data.message !== 'string') return;
      const item = { username: data.username.slice(0, 64), message: data.message.slice(0, 2000), timestamp: Number(data.timestamp) || Math.floor(Date.now()/1000) };
      history.push(item); if (history.length > MAX_HISTORY) history.shift();
      const payload = JSON.stringify({ type: 'chat', ...item });
      for (const client of wss.clients) if (client.role === 'dashboard' && client.readyState === WebSocket.OPEN) client.send(payload);
    } catch {}
  });
});
// Basic Auth is only safe over HTTPS. Configure the host/reverse proxy to provide HTTPS/WSS.
server.listen(PORT, () => console.log(`Smooth Zoom Plus relay listening on port ${PORT}; expose only behind HTTPS/WSS.`));
