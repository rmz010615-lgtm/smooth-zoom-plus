const $ = id => document.getElementById(id);
const list = $('messages'), status = $('status');
let items = [], paused = false, queued = [];
function render() {
  const q = $('search').value.toLowerCase(), u = $('userFilter').value.toLowerCase();
  list.replaceChildren();
  const filtered = items.filter(m => m.message.toLowerCase().includes(q) && m.username.toLowerCase().includes(u));
  if (!filtered.length) { const e=document.createElement('p'); e.className='empty'; e.textContent='No matching messages yet.'; list.append(e); return; }
  for (const m of filtered.slice().reverse()) {
    const card=document.createElement('article'); card.className='message';
    const meta=document.createElement('div'); meta.className='meta';
    const name=document.createElement('span'); name.className='username'; name.textContent=m.username;
    const time=document.createElement('time'); time.textContent=new Date(m.timestamp*1000).toLocaleString();
    const body=document.createElement('div'); body.textContent=m.message;
    meta.append(name,time); card.append(meta,body); list.append(card);
  }
}
$('search').addEventListener('input',render); $('userFilter').addEventListener('input',render);
$('pause').addEventListener('click',()=>{paused=!paused;$('pause').textContent=paused?'Resume feed':'Pause feed';if(!paused){items.push(...queued);queued=[];items=items.slice(-500);render();}});
$('clear').addEventListener('click',()=>{items=[];queued=[];render();});
async function start(){
  try {
    // Browser Basic Auth is prompted by the protected history endpoint.
    const response=await fetch('/api/history'); if(!response.ok) throw Error('Authentication required');
    items=await response.json(); render();
    const scheme=location.protocol==='https:'?'wss:':'ws:';
    const ws=new WebSocket(`${scheme}//${location.host}/ws/dashboard`);
    ws.onopen=()=>status.textContent='Connected';
    ws.onclose=()=>{status.textContent='Disconnected — refresh to reconnect';};
    ws.onerror=()=>status.textContent='Connection error';
    ws.onmessage=e=>{try{const data=JSON.parse(e.data);if(data.type==='history')items=data.messages.slice(-500);if(data.type==='chat'){if(paused)queued.push(data);else items.push(data);}items=items.slice(-500);render();}catch{}};
  } catch(e){status.textContent='Login failed — refresh';}
}
start();
