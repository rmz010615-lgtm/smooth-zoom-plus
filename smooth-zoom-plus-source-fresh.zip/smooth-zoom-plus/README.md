# Smooth Zoom Plus (Fabric, Minecraft Java 1.21.11)

This is a source project for a client-only smooth zoom mod plus an optional authenticated chat dashboard relay. **Chat sharing is OFF by default**. The relay is outbound-only from the Minecraft client; it does not need a server plugin. Only use sharing where you have permission to transmit the messages visible to your client.

## Compatibility / versions

Pinned versions in `gradle.properties`:
- Minecraft `1.21.11`
- Yarn mappings `1.21.11+build.6`
- Fabric Loader `0.18.1`
- Fabric API `0.141.1+1.21.11`
- Fabric Loom `1.10.5`
- Java 21

Minecraft 1.21.11 is a real release. Fabric's official guidance notes 1.21.11 is the final obfuscated release and recommends planning around Mojang mappings for later releases. Dependency coordinates are pinned, but **this source archive has not been compiled in this environment**; run the build below and resolve any upstream version/mapping differences before treating the JAR as verified. Loom may need to be raised to a compatible stable release if the pinned plugin cannot resolve the 1.21.11 toolchain.

## Build the mod

1. Install a Java 21 JDK and a recent Gradle (the wrapper is not bundled).
2. From this directory run `gradle build`.
3. The JAR should be produced in `build/libs/`.
4. Install Fabric Loader for Minecraft 1.21.11 and place the built JAR in `.minecraft/mods/` with a compatible Fabric API JAR.

## Configuration

Launch once to create `.minecraft/config/smooth-zoom-plus.json`. Sharing defaults to `false`. Adjust `zoomFactor` (1–20) and `transitionSpeed` (0.01–1.0). To share chat, first configure and secure the backend, then set `shareChat` to `true`, `relayUrl` to your `wss://host/ws/client` endpoint, and `relayToken` to the backend `CLIENT_TOKEN`. Never share the token. The keybind is C and can be changed in Minecraft Controls.

## Backend / dashboard

Requires Node.js 20+.

1. `cd backend && npm install`
2. Copy `.env.example` to `.env`.
3. Generate two long random secrets and set `CLIENT_TOKEN`, `DASHBOARD_USER`, and `DASHBOARD_PASSWORD`. Do not use the sample values.
4. `npm start` starts the relay on port 8080.
5. Deploy behind a trusted HTTPS reverse proxy or a host that provides HTTPS. The dashboard must be accessed as `https://your-host/`, and the client WebSocket endpoint must be `wss://your-host/ws/client`. Do not expose plain HTTP/WS to the internet. Basic Auth is only secure over TLS.
6. Open the HTTPS URL on the phone and enter dashboard credentials when prompted.
7. Configure the mod's relay URL/token and explicitly enable `shareChat`.

The relay stores at most 500 messages in process memory and loses them on restart. It does not write chat logs to disk. The browser dashboard authenticates history and WebSocket access. Use a private host, rotate credentials if exposed, and do not forward ports directly without TLS.

## Features

- C key zoom hold with interpolation and FOV multiplier.
- Configurable zoom strength and transition speed.
- Client-side chat message capture, local relay configuration, opt-in sharing.
- Responsive phone dashboard with live updates, search, username filter, pause/resume, clear-view, connection status, and authenticated endpoints.

## Troubleshooting

- **Mod won't load:** confirm Minecraft is exactly 1.21.11, Java 21 is selected, and Fabric API matches 1.21.11.
- **Gradle dependency not found:** verify the pinned versions on Fabric Maven and update `fabric_api_version`, `loader_version`, or Loom to a published compatible version.
- **Zoom does not change:** check Controls for Smooth Zoom Plus, test without shader/camera mods, and inspect `logs/latest.log` for mixin application errors. Camera/FOV internals can vary by mapping and patch release.
- **Dashboard won't connect:** use HTTPS/WSS, check credentials and reverse-proxy WebSocket support, verify the token and relay URL, and check backend logs.
- **No chat arrives:** `shareChat` must be true, `relayToken` must exactly match `CLIENT_TOKEN`, and the backend must be reachable. Sharing intentionally does nothing with the placeholder token.

## Security notes / limitations

This is an implementation starter, not a security-audited service. The dashboard uses HTTP Basic Auth, so TLS is mandatory. Keep it private. There is no in-game settings screen in this initial version; edit the JSON config while Minecraft is closed. The zoom mixin target may need adjustment after a real Gradle compile/run against the selected mappings. This archive does not claim a successful build or in-game test.
